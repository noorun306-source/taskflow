import Navbar from "./components/navbar";
import Dashboard from "./components/dashboard";
import TaskInput from "./components/taskcard";
function App(){
  return (
    <>
      <Navbar />
      <Dashboard/>
    <div>
      {/* <h1>Task Dashboard</h1>
      <p>Manage your tasks smarter</p> */}
    </div>
     </>
  );
}
export default App;

