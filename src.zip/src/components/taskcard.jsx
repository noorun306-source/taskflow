 import "./taskcard.css";
function TaskCard({task,onToggle,onDelete}) {
    return (
        <div className="task-card">

            <div className="task-left">
            
                <input 
                type="checkbox"
                checked={task.completed}
                onChange={onToggle}
                />
               <span className={ tasks.completed ? "completed" : ""}>
         {task.text}
                </span>
               </div>
            
            <button onClick={onDelete}>Delete</button>
        </div>
    );
}
export default TaskCard;