import { useState } from "react";
import "./dashboard.css";
import TaskInput from "./taskinput";
import TaskCard from "./taskcard";
 function Dashboard(){
      const [tasks, SetTasks] = useState([]);

      const addTask = (newTask) => {
        SetTasks([
            ...tasks,
            {
                Text: newTask,
                completed: false,
            },
        ]);
      };
       
      const toggleTask = (index) => {
        SetTasks(
            tasks.map((task, i) => 
            i === index 
            ? {...task,  completed: !task.completed } : task     
        )
      );
     };

     const deleteTask = (index) => {
        SetTasks(tasks.filter((_, i) !== index));
    SetTasks(updatedTasks);
      };

      const completed = tasks.filter(task => task.completed).length;
    //   const PendingCount = tasks.length - completedCount;

    return (
        <div className="dashboard">
            <h1>Task Dashboard</h1>
            <p>Manage your task smarter</p>

            <div className="cards">
                <div className="card">
                    <h3>Total Tasks</h3>
                    <h2>{tasks.length}</h2>
                </div>

                <div className="card">
                    <h3>Completed</h3>
                    <h2>0</h2>
                </div>
                
                <div className="card">
                    <h3>Pending</h3>
                    <h2>{tasks.length}</h2>

                </div>
            </div>
            <TaskInput addTask ={addTask}/>

            <div className="task-list">
                {tasks.map((task, index) => (
                    <TaskCard
                    key={index}
                    task={task}
                    onToggle={() => toggleTask(index)}
                    onDelete={() => deleteTask(index)}
                    />
                ))}
            </div>
        </div>
    );
}
export default Dashboard;