
import { useState } from "react";
import "./taskinput.css";
function TaskInput({addTask}) {
    const [task, SetTask] = useState("");

    const handleAddTask = () => {
        if(task.trim() === "") return;

        addTask(task);
        SetTask("");
    };
 return (
    <div className="task-input">
        <input type="text" placeholder="Enter a task.."
        value={task}
        onChange={(e) => SetTask(e.target.value)}
        />
        <button onClick = {handleAddTask}>Add Task</button>
    </div>
 );
}
export default TaskInput;